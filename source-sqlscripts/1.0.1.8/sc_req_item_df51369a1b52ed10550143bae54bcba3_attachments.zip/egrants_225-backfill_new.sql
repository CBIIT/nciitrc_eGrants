-- Create temp table for local import of impacted records
select appl_id, new_email_address into eim.dbo.appls_dm from (select a.appl_id, a.pi_email_addr as new_email_address
from openquery(IRDB, 'select p.appl_id, c.email_addr pi_email_addr, pi_first_name, pi_last_name, pi_role_person_id
from PVA_GRANT_PI_MV p
left outer join person_involvements_mv b on b.appl_id = p.appl_id
and b.role_type_code = ''PI''
and b.version_code <> ''W''
left outer join person_addresses_mv c on c.person_id = b.person_id
and c.addr_type_code = ''HOM''
and c.preferred_addr_code = ''Y''
where fy > 2022') a
inner 
join appls b
on a.appl_id = b.appl_id
where b.appl_id = dbo.fn_grant_latest_appl(b.grant_id) 
and a.pi_email_addr collate database_default != b.pi_email_addr collate database_default
and  a.pi_role_person_id = b.person_id
) appls_dm;

-- Create temp index
CREATE INDEX appls_dm_idx ON eim.dbo.appls_dm(appl_id);

-- Update query for FY > 2022
update appls 
set pi_email_addr = appls_dm.new_email_address
from appls
inner join appls_dm 
on appls.appl_id = appls_dm.appl_id; 

drop table appls_dm;